import './App.css'
import React, { useRef, useEffect } from 'react'
import { Grid, Paper } from '@material-ui/core'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

function App() {
    const gridRef = useRef()

    useEffect(() => {
        gsap.to('.text-box', {
            x: 50,
            duration: 2,
            ease: 'bounce',
            delay: 1,
            scrollTrigger: {
                trigger: '.container',
                markers: false,
                start: 'center bottom',
            },
        })
        gsap.to('.item-container', {
            x: -50,
            duration: 3,
            ease: 'bounce',
            rotate: '360',
            delay: 1,
            scrollTrigger: {
                trigger: '.container',
                markers: false,
                start: 'center bottom',
            },
        })
    }, [])

    return (
        <>
            <div className="container" ref={gridRef}>
                <div className="text-box">
                    <h1>What We Offer</h1>
                    <h2>Fitness Resorts</h2>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Quae aut nihil quia, eius cumque deleniti!
                    </p>
                </div>
                <Grid container spacing={1} className="grid-container">
                    <Grid item xs={4} md={4}>
                        <Paper></Paper>
                    </Grid>
                    <Grid item xs={4} md={4}>
                        <Paper className="item-container">
                            <div className="item bg">
                                <img src="https://img.icons8.com/external-konkapp-detailed-outline-konkapp/64/000000/external-gym-gym-konkapp-detailed-outline-konkapp.png" />
                                <p>Gym</p>
                            </div>
                        </Paper>
                    </Grid>
                    <Grid item xs={4} md={4}>
                        <Paper className="item-container">
                            <div className="item bg2">
                                <img src="https://img.icons8.com/external-vitaliy-gorbachev-lineal-vitaly-gorbachev/60/000000/external-yoga-mat-health-vitaliy-gorbachev-lineal-vitaly-gorbachev.png" />
                                <p>Yoga</p>
                            </div>
                        </Paper>
                    </Grid>
                    <Grid item xs={4} md={4}>
                        <Paper className="item-container">
                            <div className="item bg">
                                <img src="https://img.icons8.com/external-victoruler-outline-victoruler/64/000000/external-sport-shoe-clothes-and-outfit-victoruler-outline-victoruler.png" />
                                <p>Equipment</p>
                            </div>
                        </Paper>
                    </Grid>
                    <Grid item xs={4} md={4}>
                        <Paper className="item-container">
                            <div className="item bg2">
                                <img src="https://img.icons8.com/external-icongeek26-outline-icongeek26/64/000000/external-supplements-healthy-lifestyle-icongeek26-outline-icongeek26.png" />
                                <p>Supplements</p>
                            </div>
                        </Paper>
                    </Grid>
                    <Grid item xs={4} md={4}>
                        <Paper className="item-container">
                            <div className="item bg">
                                <img src="https://img.icons8.com/external-konkapp-detailed-outline-konkapp/64/000000/external-lockers-gym-konkapp-detailed-outline-konkapp.png" />
                                <p>Locker Rooms</p>
                            </div>
                        </Paper>
                    </Grid>
                </Grid>
            </div>
        </>
    )
}

export default App
